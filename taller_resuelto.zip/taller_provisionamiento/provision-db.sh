#!/usr/bin/env bash

# Actualizar paquetes
sudo apt-get update -y

# Instalar PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Habilitar PostgreSQL al inicio
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Crear base de datos y usuario
sudo -u postgres psql -c "CREATE USER vagrant WITH PASSWORD 'vagrant';"
sudo -u postgres psql -c "CREATE DATABASE webapp OWNER vagrant;"

# Crear tabla y datos de ejemplo
sudo -u postgres psql -d webapp -c "
CREATE TABLE IF NOT EXISTS productos (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(50),
  precio NUMERIC
);
INSERT INTO productos (nombre, precio) VALUES
('Teclado mecánico', 150.00),
('Mouse inalámbrico', 90.00),
('Monitor 24 pulgadas', 800.00);
"

# Permitir conexiones desde la red privada (192.168.56.0/24)
sudo bash -c "echo 'host all all 192.168.56.0/24 md5' >> /etc/postgresql/12/main/pg_hba.conf"

# Escuchar conexiones en todas las interfaces
sudo sed -i \"/^#listen_addresses/c\\listen_addresses='*'\" /etc/postgresql/12/main/postgresql.conf

# Reiniciar PostgreSQL
sudo systemctl restart postgresql


#para que se pueda ejecutar por si mismo
#chmod +x provision-db.sh
