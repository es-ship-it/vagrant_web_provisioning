# Taller Vagrant + Provisionamiento con Shell

## Pasos
1. Clonar este repositorio.
2. Ejecutar `vagrant up` para levantar las máquinas.
3. Acceder a la máquina web en: http://192.168.56.10
4. Verificar `index.html` y `info.php`.

## Reto
- Completar `provision-db.sh` para instalar PostgreSQL.
- Crear una base de datos y tabla.
- Conectar la página PHP a la base de datos y mostrar datos.



## solucion 
- se provisiono con codigo provision-db.sh
- se creo la base de datos
- se instalaron los recursos necesarios como postgresql
- se definieron las ip
- se comprobo que abriera todo correcto tanto en httml http://192.168.56.10/bd.php, como en http://192.168.56.10/info.php y en http://192.168.56.10/
- imagenes: 
- ![alt text](image.png)
- ![alt text](image-1.png)
- ![alt text](image-2.png)
