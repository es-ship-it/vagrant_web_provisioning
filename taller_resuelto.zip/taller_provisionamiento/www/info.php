<?php
  echo "<h1>Hola soy Emmanuel desde PHP 😎😎</h1>";
  echo "<p>Fecha actual: " . date("Y-m-d H:i:s") . "</p>";
  phpinfo();
?>
