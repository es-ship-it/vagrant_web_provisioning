<?php
$host = "192.168.56.20";
$dbname = "webapp";
$user = "vagrant";
$password = "vagrant";

try {
    $conn = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $result = $conn->query("SELECT * FROM productos");
    
    echo "<h1>Lista de Productos</h1>";
    echo "<ul>";
    foreach ($result as $row) {
        echo "<li>{$row['nombre']} - {$row['precio']}</li>";
    }
    echo "</ul>";
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}
?>
